# Smart Watering System KICAD project

## Como abrir?

### Pré-requisitos

- Ter instalado o software KiCad na versão 7.0

### Passo-a-Passo para acessar o projeto

- Abra o software KiCad
- Clique no atalho ctrl+O
- Selecione o arquivo "smart_watering_system"